from pymongo import MongoClient
import serial
import itertools
import time

client = MongoClient("mongodb://localhost:27017")
arduinoSerialData = serial.Serial('/dev/ttyUSB0', 9600)
time.sleep(2)
db = client.via
mydata1 = ""
buffer_string = ""

def receiving(arduinoSerialData):
    global last_received
    global buffer_string
    while True:
        buffer_string = arduinoSerialData.read(arduinoSerialData.inWaiting())
        if '\n' in buffer_string:
            lines = buffer_string.split('\n') # Guaranteed to have at least 2 entries
            last_received = lines[-2]
            buffer_string = lines[-1]
            print lines
            print buffer_string
            return

while 1:
    if arduinoSerialData.inWaiting():
            arduinoSerialData.flush()
            time.sleep(2)
            receiving(arduinoSerialData)
            print buffer_string
            dicto =  db.vehicle_pass.count({"vehicle_no":str(buffer_string).rstrip()})
            #print mydata
            if dicto == 1:
                arduinoSerialData.write('1\n')
            else:
                arduinoSerialData.write('2\n')
