from pymongo import MongoClient
import serial
import itertools
import time

client = MongoClient("mongodb://localhost:27017")
arduinoSerialData = serial.Serial('/dev/ttyUSB0', 9600)
time.sleep(2)
db = client.via
veh_details = []
cnt = 0
mydata1 = ""
while 1:
    if arduinoSerialData.inWaiting():
            arduinoSerialData.flush()
            mydata = str(arduinoSerialData.readline()).replace("\n", "").strip()
            time.sleep(2)
            if mydata != mydata1:
                mydata1 = mydata
                dicto =  db.vehicle_pass.count({"vehicle_no":str(mydata).rstrip()})
                print mydata
                if dicto == 1:
                    arduinoSerialData.write('1\n')
                    mydata = str(arduinoSerialData.readline()).replace("\n", "").strip()
                else:
                    arduinoSerialData.write('2\n')
                    mydata = str(arduinoSerialData.readline()).replace("\n", "").strip()
            else:
                arduinoSerialData.write('2\n')
                #mydata = str(arduinoSerialData.readline()).replace("\n", "").strip()
