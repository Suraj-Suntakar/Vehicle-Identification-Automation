from pymongo import MongoClient
import serial
import datetime

client = MongoClient("mongodb://localhost:27017")
db = client.projectvia
arduinoSerialData = serial.Serial('/dev/ttyUSB0',9600)

while 1:
	if arduinoSerialData.inWaiting()>0:
		mydata = str(arduinoSerialData.readline()).replace("\n", "").strip()
		print mydata
		cnt =  db.vehicle.count({"vehicle_no": mydata})
		if cnt == 1:
			arduinoSerialData.write('1\n')
			dicto =  db.vehicle.find({"vehicle_no": mydata})
			for row in dicto:
				row['gate'] = '1'
				del row['_id']
				row['timestamp'] = datetime.datetime.now()
				db.logbook.insert(row)
		else:
			arduinoSerialData.write('2\n')
