from pymongo import MongoClient
import serial
import datetime
print(ts)
ts = datetime.datetime.now()
print(ts)
