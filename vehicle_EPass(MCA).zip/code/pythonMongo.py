from pymongo import MongoClient
from pprint import pprint
import serial

client = MongoClient("mongodb://localhost:27017")
arduinoSerialData = serial.Serial('/dev/ttyUSB0', 9600)
db = client.via
mydata = ''
veh_details = []
while 1:
    if arduinoSerialData.inWaiting()>0:
        mydata = arduinoSerialData.readline()
        print mydata
        veh_details = str(mydata).split('\n')
        print db.vehicle_pass.find_one({"vehicle_no":veh_details[0]})
        n = str(input("enter: "))
        arduinoSerialData.write(n+'\n')
