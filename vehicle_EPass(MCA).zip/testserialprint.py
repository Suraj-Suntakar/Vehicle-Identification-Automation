import serial
arduinoSerialData = serial.Serial('/dev/ttyUSB0', 9600)
while 1:
	if arduinoSerialData.inWaiting()>0:
		mydata = arduinoSerialData.readline()
		print mydata
	n = str(input("enter: "))
	arduinoSerialData.write(n+'\n')
